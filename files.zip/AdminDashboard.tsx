// File: components/admin-dashboard/AdminDashboard.tsx
'use client'

import { useEffect, useState } from 'react'
import { DollarSign, TrendingUp, Users, CheckCircle, AlertCircle, Download } from 'lucide-react'

interface AdminDashboardData {
  revenue: {
    today: string
    week: string
    month: string
    monthlyMembership: string
    lifetimeMembership: string
  }
  commissions: {
    pending: string
    payable: string
    paid: string
    outstanding: string
  }
  topAffiliates: Array<{
    id: string
    name: string
    earnings: number
    conversions: number
    clicks: number
  }>
  recentSales: Array<{
    id: string
    affiliateName: string
    customerName: string
    customerEmail: string
    productType: string
    amount: string
    status: string
    date: string
  }>
  pendingPayouts: Array<{
    id: string
    affiliateName: string
    affiliateEmail: string
    amount: string
    date: string
  }>
  payoutQueue: Array<{
    affiliateName: string
    affiliateEmail: string
    amount: string
  }>
}

export default function AdminDashboard() {
  const [data, setData] = useState<AdminDashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedPayouts, setSelectedPayouts] = useState<string[]>([])

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch('/api/admin/dashboard')
        const json = await res.json()
        setData(json)
      } catch (error) {
        console.error('Failed to load admin dashboard:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  if (loading) return <div className="p-8 text-center">Loading...</div>
  if (!data) return <div className="p-8 text-center">Failed to load data</div>

  const markPayoutAsPaid = async (payoutId: string) => {
    try {
      const response = await fetch('/api/admin/payouts', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          payoutId,
          paymentDate: new Date().toISOString(),
          paymentReference: prompt('Enter payment reference (e.g., transfer ID):'),
        }),
      })

      if (response.ok) {
        alert('Payout marked as paid!')
        // Refresh data
        window.location.reload()
      }
    } catch (error) {
      console.error('Failed to mark payout as paid:', error)
    }
  }

  const exportToCSV = () => {
    // Sales data
    const salesHeaders = ['Date', 'Affiliate', 'Customer', 'Email', 'Product Type', 'Amount', 'Status']
    const salesRows = data.recentSales.map((sale) => [
      sale.date,
      sale.affiliateName,
      sale.customerName,
      sale.customerEmail,
      sale.productType,
      sale.amount,
      sale.status,
    ])

    const csv =
      [salesHeaders, ...salesRows].map((row) => row.map((cell) => `"${cell}"`).join(',')).join('\n') +
      '\n\n' +
      ['Affiliate', 'Email', 'Amount', 'Status']
        .map((header) => `"${header}"`)
        .join(',') +
      '\n' +
      data.pendingPayouts.map((payout) =>
        [payout.affiliateName, payout.affiliateEmail, payout.amount, 'Pending']
          .map((cell) => `"${cell}"`)
          .join(',')
      )

    const blob = new Blob([csv], { type: 'text/csv' })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `affiliate-data-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-4xl font-bold mb-2">Affiliate Management</h1>
            <p className="text-slate-400">Monitor affiliates, track commissions, and manage payouts</p>
          </div>
          <button
            onClick={exportToCSV}
            className="flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg font-semibold transition"
          >
            <Download size={20} />
            Export Data
          </button>
        </div>

        {/* Revenue Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <MetricCard label="Today's Revenue" value={`$${data.revenue.today}`} icon={<TrendingUp size={24} />} />
          <MetricCard label="Weekly Revenue" value={`$${data.revenue.week}`} icon={<TrendingUp size={24} />} />
          <MetricCard label="Monthly Revenue" value={`$${data.revenue.month}`} icon={<DollarSign size={24} />} />
          <MetricCard
            label="Monthly Membership"
            value={`$${data.revenue.monthlyMembership}`}
            icon={<Users size={24} />}
          />
          <MetricCard
            label="Lifetime Membership"
            value={`$${data.revenue.lifetimeMembership}`}
            icon={<Users size={24} />}
          />
        </div>

        {/* Commission Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <CommissionCard
            label="Pending (30-day)"
            value={`$${data.commissions.pending}`}
            icon={<AlertCircle size={24} />}
            color="yellow"
          />
          <CommissionCard
            label="Ready to Pay"
            value={`$${data.commissions.payable}`}
            icon={<CheckCircle size={24} />}
            color="green"
          />
          <CommissionCard
            label="Already Paid"
            value={`$${data.commissions.paid}`}
            icon={<DollarSign size={24} />}
            color="blue"
          />
          <CommissionCard
            label="Outstanding"
            value={`$${data.commissions.outstanding}`}
            icon={<AlertCircle size={24} />}
            color="red"
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Top Affiliates */}
          <div className="lg:col-span-1 bg-slate-800 border border-slate-700 rounded-xl p-6">
            <h3 className="text-xl font-bold mb-6">Top Affiliates</h3>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {data.topAffiliates.map((affiliate, idx) => (
                <div key={affiliate.id} className="bg-slate-700 rounded-lg p-4 border-l-4 border-amber-500">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <p className="font-bold">#{idx + 1}</p>
                      <p className="text-sm text-slate-300">{affiliate.name}</p>
                    </div>
                    <p className="text-amber-400 font-bold text-lg">${affiliate.earnings.toFixed(2)}</p>
                  </div>
                  <div className="flex gap-4 text-xs text-slate-400">
                    <span>📊 {affiliate.clicks} clicks</span>
                    <span>✓ {affiliate.conversions} conversions</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Sales */}
          <div className="lg:col-span-2 bg-slate-800 border border-slate-700 rounded-xl p-6">
            <h3 className="text-xl font-bold mb-6">Recent Sales</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-slate-600">
                  <tr className="text-slate-400">
                    <th className="text-left py-3 px-3">Date</th>
                    <th className="text-left py-3 px-3">Affiliate</th>
                    <th className="text-left py-3 px-3">Customer</th>
                    <th className="text-left py-3 px-3">Type</th>
                    <th className="text-right py-3 px-3">Amount</th>
                    <th className="text-center py-3 px-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {data.recentSales.slice(0, 15).map((sale) => (
                    <tr key={sale.id} className="border-b border-slate-700 hover:bg-slate-700 transition">
                      <td className="py-3 px-3 text-slate-400 text-xs">
                        {new Date(sale.date).toLocaleDateString()}
                      </td>
                      <td className="py-3 px-3 font-semibold">{sale.affiliateName}</td>
                      <td className="py-3 px-3 text-slate-300">
                        {sale.customerName}
                        <br />
                        <span className="text-xs text-slate-500">{sale.customerEmail}</span>
                      </td>
                      <td className="py-3 px-3">
                        <span className={sale.productType === 'monthly' ? 'text-purple-400' : 'text-pink-400'}>
                          {sale.productType}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-green-400">${sale.amount}</td>
                      <td className="py-3 px-3 text-center">
                        <span
                          className={`px-2 py-1 rounded text-xs font-semibold ${
                            sale.status === 'succeeded'
                              ? 'bg-green-900 text-green-300'
                              : 'bg-yellow-900 text-yellow-300'
                          }`}
                        >
                          {sale.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Payout Queue */}
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
          <h3 className="text-2xl font-bold mb-6">Payout Queue (Affiliates Awaiting Payment)</h3>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Queue Summary */}
            <div>
              <div className="bg-gradient-to-br from-green-900 to-green-800 rounded-lg p-6 mb-6 border border-green-700">
                <p className="text-green-200 text-sm font-semibold">Ready for Payout</p>
                <p className="text-4xl font-bold text-green-400 mt-2">
                  ${data.payoutQueue
                    .reduce((sum, item) => sum + parseFloat(item.amount), 0)
                    .toFixed(2)}
                </p>
                <p className="text-green-300 text-sm mt-2">{data.payoutQueue.length} affiliates</p>
              </div>

              <div className="space-y-3 max-h-96 overflow-y-auto">
                {data.payoutQueue.length > 0 ? (
                  data.payoutQueue.map((item, idx) => (
                    <div key={idx} className="bg-slate-700 rounded-lg p-4 border border-green-700">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <p className="font-bold text-green-400">{item.affiliateName}</p>
                          <p className="text-slate-400 text-sm">{item.affiliateEmail}</p>
                        </div>
                        <p className="text-2xl font-bold text-green-400">${item.amount}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-400 text-center py-8">No payouts pending</p>
                )}
              </div>
            </div>

            {/* Instructions */}
            <div className="bg-slate-700 rounded-lg p-6 border border-slate-600">
              <h4 className="font-bold text-lg mb-4">Payout Instructions</h4>
              <ol className="space-y-4 text-slate-300 text-sm">
                <li className="flex gap-3">
                  <span className="font-bold text-amber-400 flex-shrink-0">1.</span>
                  <span>Review the payout queue above</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-amber-400 flex-shrink-0">2.</span>
                  <span>Transfer funds to each affiliate's bank account</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-amber-400 flex-shrink-0">3.</span>
                  <span>Click "Mark as Paid" for each payout below</span>
                </li>
                <li className="flex gap-3">
                  <span className="font-bold text-amber-400 flex-shrink-0">4.</span>
                  <span>Enter payment reference (transfer ID) for records</span>
                </li>
              </ol>

              <div className="mt-6 p-4 bg-blue-900 border border-blue-700 rounded-lg">
                <p className="text-blue-300 text-sm">
                  💡 <strong>Tip:</strong> Export the data above to get a full record of all sales and affiliate
                  information for your accounting.
                </p>
              </div>
            </div>
          </div>

          {/* Pending Payouts Table */}
          {data.pendingPayouts.length > 0 && (
            <div className="mt-8">
              <h4 className="font-bold mb-4">Pending Payouts</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="border-b border-slate-600">
                    <tr className="text-slate-400">
                      <th className="text-left py-3 px-3">Affiliate</th>
                      <th className="text-left py-3 px-3">Email</th>
                      <th className="text-right py-3 px-3">Amount</th>
                      <th className="text-left py-3 px-3">Date</th>
                      <th className="text-center py-3 px-3">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.pendingPayouts.map((payout) => (
                      <tr key={payout.id} className="border-b border-slate-700 hover:bg-slate-700 transition">
                        <td className="py-3 px-3 font-semibold">{payout.affiliateName}</td>
                        <td className="py-3 px-3 text-slate-400">{payout.affiliateEmail}</td>
                        <td className="py-3 px-3 text-right font-bold text-green-400">${payout.amount}</td>
                        <td className="py-3 px-3 text-slate-400 text-xs">
                          {new Date(payout.date).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-3 text-center">
                          <button
                            onClick={() => markPayoutAsPaid(payout.id)}
                            className="px-3 py-1 bg-green-600 hover:bg-green-700 rounded text-xs font-semibold transition"
                          >
                            Mark Paid
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function MetricCard({
  label,
  value,
  icon,
}: {
  label: string
  value: string
  icon: React.ReactNode
}) {
  return (
    <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
      <div className="flex items-center justify-between mb-2">
        <p className="text-slate-400 text-xs font-semibold">{label}</p>
        <div className="text-slate-500">{icon}</div>
      </div>
      <p className="text-2xl font-bold text-white">{value}</p>
    </div>
  )
}

function CommissionCard({
  label,
  value,
  icon,
  color,
}: {
  label: string
  value: string
  icon: React.ReactNode
  color: 'yellow' | 'green' | 'blue' | 'red'
}) {
  const colorClasses = {
    yellow: 'bg-yellow-900/20 border-yellow-700 text-yellow-400',
    green: 'bg-green-900/20 border-green-700 text-green-400',
    blue: 'bg-blue-900/20 border-blue-700 text-blue-400',
    red: 'bg-red-900/20 border-red-700 text-red-400',
  }

  return (
    <div className={`rounded-xl p-6 border ${colorClasses[color]}`}>
      <div className="flex items-center justify-between mb-3">
        <p className="text-sm font-semibold opacity-75">{label}</p>
        <div>{icon}</div>
      </div>
      <p className="text-3xl font-bold">{value}</p>
    </div>
  )
}
