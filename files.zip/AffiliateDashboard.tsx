// File: components/affiliate-dashboard/AffiliateDashboard.tsx
'use client'

import { useEffect, useState } from 'react'
import QRCode from 'qrcode.react'
import { Copy, Share2, TrendingUp, DollarSign, Users, BarChart3 } from 'lucide-react'

interface DashboardData {
  affiliate: {
    id: string
    fullName: string
    referralCode: string
    status: string
    lifetimeEarnings: number
  }
  stats: {
    totalClicks: number
    totalConversions: number
    conversionRate: string
    monthlyRevenue: string
    lifetimeRevenue: string
  }
  commissions: {
    pending: string
    payable: string
    paid: string
  }
  recentSales: Array<{
    id: string
    customerName: string
    productType: string
    amount: string
    status: string
    date: string
  }>
  leaderboard: {
    position: number
    totalAffiliates: number
  }
}

export default function AffiliateDashboard({ affiliateId }: { affiliateId: string }) {
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`/api/affiliates/dashboard?affiliateId=${affiliateId}`)
        const json = await res.json()
        setData(json)
      } catch (error) {
        console.error('Failed to load dashboard:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [affiliateId])

  if (loading) return <div className="p-8 text-center">Loading...</div>
  if (!data) return <div className="p-8 text-center">Failed to load data</div>

  const referralUrl = `${typeof window !== 'undefined' ? window.location.origin : ''}?ref=${data.affiliate.referralCode}`

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(referralUrl)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  const shareOnSocial = (platform: string) => {
    const text = `Join Preemiyum Stats - Australia's Premium Sports Betting Community! Use my referral link:`
    const urls: Record<string, string> = {
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(referralUrl)}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralUrl)}`,
      whatsapp: `https://wa.me/?text=${encodeURIComponent(`${text} ${referralUrl}`)}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(referralUrl)}`,
    }
    if (urls[platform]) window.open(urls[platform], '_blank')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Affiliate Dashboard</h1>
          <p className="text-slate-400">
            Welcome, {data.affiliate.fullName} • Status:{' '}
            <span
              className={
                data.affiliate.status === 'approved'
                  ? 'text-green-400 font-semibold'
                  : 'text-yellow-400 font-semibold'
              }
            >
              {data.affiliate.status.toUpperCase()}
            </span>
          </p>
        </div>

        {/* Referral Link Section */}
        <div className="bg-slate-800 border border-slate-700 rounded-xl p-8 mb-8">
          <h2 className="text-2xl font-bold mb-6">Your Referral Link</h2>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Referral Code */}
            <div className="lg:col-span-2">
              <div className="bg-slate-700 rounded-lg p-6 border border-slate-600 mb-4">
                <p className="text-slate-300 text-sm mb-2">Referral Code</p>
                <p className="text-3xl font-mono font-bold text-amber-400 mb-4">
                  {data.affiliate.referralCode}
                </p>

                <div className="bg-slate-800 rounded-lg p-4 mb-4 break-all">
                  <p className="text-slate-400 text-sm mb-1">Full Link</p>
                  <p className="text-slate-200 font-mono text-sm">{referralUrl}</p>
                </div>

                <div className="flex gap-3 flex-wrap">
                  <button
                    onClick={copyToClipboard}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition ${
                      copied
                        ? 'bg-green-600 text-white'
                        : 'bg-amber-500 hover:bg-amber-600 text-black'
                    }`}
                  >
                    <Copy size={18} />
                    {copied ? 'Copied!' : 'Copy Link'}
                  </button>

                  <button className="flex items-center gap-2 px-4 py-2 rounded-lg font-semibold bg-slate-700 hover:bg-slate-600 transition">
                    <Share2 size={18} />
                    Share
                  </button>
                </div>
              </div>

              {/* Social Share Buttons */}
              <div className="bg-slate-700 rounded-lg p-4 border border-slate-600">
                <p className="text-sm text-slate-300 mb-3">Share on Social Media</p>
                <div className="flex gap-2 flex-wrap">
                  {[
                    { name: 'Twitter', icon: '𝕏' },
                    { name: 'Facebook', icon: 'f' },
                    { name: 'WhatsApp', icon: '💬' },
                    { name: 'LinkedIn', icon: 'in' },
                  ].map((social) => (
                    <button
                      key={social.name}
                      onClick={() => shareOnSocial(social.name.toLowerCase())}
                      className="px-4 py-2 bg-slate-600 hover:bg-slate-500 rounded-lg transition text-sm font-semibold"
                    >
                      {social.icon} {social.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* QR Code */}
            <div className="flex flex-col items-center justify-center bg-slate-700 rounded-lg p-6 border border-slate-600">
              <p className="text-slate-300 text-sm mb-3">Scan to Share</p>
              <div className="bg-white p-3 rounded-lg">
                <QRCode value={referralUrl} size={200} />
              </div>
              <p className="text-slate-400 text-xs mt-3 text-center">
                Share this QR code with friends
              </p>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard icon={<Users size={24} />} label="Clicks" value={data.stats.totalClicks} />
          <StatCard icon={<TrendingUp size={24} />} label="Conversions" value={data.stats.totalConversions} />
          <StatCard
            icon={<BarChart3 size={24} />}
            label="Conversion Rate"
            value={data.stats.conversionRate}
          />
          <StatCard
            icon={<DollarSign size={24} />}
            label="Lifetime Earnings"
            value={`$${data.affiliate.lifetimeEarnings.toFixed(2)}`}
          />
        </div>

        {/* Commission & Revenue Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Commission Status */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
            <h3 className="text-xl font-bold mb-6">Commission Status</h3>
            <div className="space-y-4">
              <div className="bg-slate-700 rounded-lg p-4">
                <p className="text-slate-400 text-sm">Pending (30-day protection)</p>
                <p className="text-3xl font-bold text-yellow-400 mt-1">${data.commissions.pending}</p>
              </div>
              <div className="bg-slate-700 rounded-lg p-4">
                <p className="text-slate-400 text-sm">Available for Payout</p>
                <p className="text-3xl font-bold text-green-400 mt-1">${data.commissions.payable}</p>
              </div>
              <div className="bg-slate-700 rounded-lg p-4">
                <p className="text-slate-400 text-sm">Already Paid</p>
                <p className="text-3xl font-bold text-blue-400 mt-1">${data.commissions.paid}</p>
              </div>
            </div>
          </div>

          {/* Revenue Breakdown */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
            <h3 className="text-xl font-bold mb-6">Revenue Breakdown</h3>
            <div className="space-y-4">
              <div className="bg-slate-700 rounded-lg p-4">
                <p className="text-slate-400 text-sm">Monthly Membership Revenue</p>
                <p className="text-3xl font-bold text-purple-400 mt-1">
                  ${data.stats.monthlyRevenue}
                </p>
              </div>
              <div className="bg-slate-700 rounded-lg p-4">
                <p className="text-slate-400 text-sm">Lifetime Membership Revenue</p>
                <p className="text-3xl font-bold text-pink-400 mt-1">
                  ${data.stats.lifetimeRevenue}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Sales & Leaderboard */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Sales */}
          <div className="lg:col-span-2 bg-slate-800 border border-slate-700 rounded-xl p-6">
            <h3 className="text-xl font-bold mb-6">Recent Sales</h3>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {data.recentSales.length > 0 ? (
                data.recentSales.map((sale) => (
                  <div key={sale.id} className="bg-slate-700 rounded-lg p-4 flex justify-between items-start">
                    <div>
                      <p className="font-semibold">{sale.customerName}</p>
                      <p className="text-slate-400 text-sm">
                        {sale.productType === 'monthly' ? '📅 Monthly' : '♾️ Lifetime'}
                      </p>
                      <p className="text-slate-500 text-xs mt-1">{sale.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg text-green-400">${sale.amount}</p>
                      <p
                        className={`text-xs font-semibold ${
                          sale.status === 'succeeded' ? 'text-green-400' : 'text-yellow-400'
                        }`}
                      >
                        {sale.status}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-slate-400 text-center py-8">No sales yet</p>
              )}
            </div>
          </div>

          {/* Leaderboard */}
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
            <h3 className="text-xl font-bold mb-6">Leaderboard</h3>
            <div className="bg-gradient-to-br from-amber-500 to-orange-500 rounded-lg p-6 text-black">
              <p className="text-sm font-semibold opacity-90">Your Position</p>
              <p className="text-5xl font-bold mt-2">#{data.leaderboard.position}</p>
              <p className="text-sm mt-3 opacity-90">
                out of {data.leaderboard.totalAffiliates} affiliates
              </p>
            </div>
            <p className="text-slate-400 text-center text-sm mt-6">
              Keep growing your referrals to climb higher!
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function StatCard({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode
  label: string
  value: string | number
}) {
  return (
    <div className="bg-slate-800 border border-slate-700 rounded-xl p-6">
      <div className="flex items-center justify-between mb-3">
        <p className="text-slate-400 text-sm font-semibold">{label}</p>
        <div className="text-slate-500">{icon}</div>
      </div>
      <p className="text-3xl font-bold text-white">{value}</p>
    </div>
  )
}
