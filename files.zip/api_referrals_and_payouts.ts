// File: app/api/referrals/track/route.ts & app/api/admin/payouts/route.ts
import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

/**
 * POST /api/referrals/track
 * Track a referral click
 * Body: { referralCode, visitorId, visitorIp, userAgent, country }
 */
export async function POST(req: NextRequest) {
  if (req.nextUrl.pathname.includes('/referrals/track')) {
    try {
      const { referralCode, visitorId, visitorIp, userAgent, country } = await req.json()

      if (!referralCode) {
        return NextResponse.json({ error: 'Missing referralCode' }, { status: 400 })
      }

      // Find affiliate
      const { data: affiliate } = await supabase
        .from('affiliates')
        .select('id')
        .eq('referral_code', referralCode)
        .single()

      if (!affiliate) {
        return NextResponse.json({ error: 'Invalid referral code' }, { status: 404 })
      }

      // Check if visitor already tracked
      const { data: existingReferral } = await supabase
        .from('referrals')
        .select('id')
        .eq('visitor_id', visitorId)
        .eq('affiliate_id', affiliate.id)
        .single()

      if (existingReferral) {
        // Update existing referral
        await supabase
          .from('referrals')
          .update({
            click_count: existingReferral.click_count + 1,
            last_click_at: new Date(),
          })
          .eq('id', existingReferral.id)
      } else {
        // Create new referral
        await supabase.from('referrals').insert({
          affiliate_id: affiliate.id,
          referral_code: referralCode,
          visitor_id: visitorId,
          visitor_ip: visitorIp,
          visitor_user_agent: userAgent,
          visitor_country: country,
          click_count: 1,
          first_click_at: new Date(),
          last_click_at: new Date(),
        })
      }

      // Update affiliate click stats
      await supabase
        .from('affiliates')
        .update({ total_clicks: affiliate.total_clicks + 1 })
        .eq('id', affiliate.id)

      return NextResponse.json({ success: true }, { status: 200 })
    } catch (error) {
      console.error('Referral tracking error:', error)
      return NextResponse.json(
        { error: error instanceof Error ? error.message : 'Unknown error' },
        { status: 500 }
      )
    }
  }

  // This won't be reached due to separate route file
  return NextResponse.json({ error: 'Not found' }, { status: 404 })
}

// ============================================================================
// File: app/api/admin/payouts/route.ts
// ============================================================================

/**
 * POST /api/admin/payouts/mark-paid
 * Mark a payout as paid
 * Body: { payoutId, paymentDate, paymentReference, notes }
 */
export async function PUT(req: NextRequest) {
  if (req.nextUrl.pathname.includes('/admin/payouts')) {
    try {
      const { payoutId, paymentDate, paymentReference, notes } = await req.json()

      if (!payoutId) {
        return NextResponse.json({ error: 'Missing payoutId' }, { status: 400 })
      }

      // Get payout details
      const { data: payout } = await supabase
        .from('affiliate_payouts')
        .select('id, affiliate_id, amount_cents')
        .eq('id', payoutId)
        .single()

      if (!payout) {
        return NextResponse.json({ error: 'Payout not found' }, { status: 404 })
      }

      // Update payout status
      await supabase
        .from('affiliate_payouts')
        .update({
          status: 'paid',
          paid_date: paymentDate || new Date(),
          payment_reference: paymentReference || null,
          notes: notes || null,
        })
        .eq('id', payoutId)

      // Update associated commission records
      const { data: commissions } = await supabase
        .from('affiliate_commissions')
        .select('id')
        .eq('affiliate_id', payout.affiliate_id)
        .eq('status', 'payable')

      for (const commission of commissions || []) {
        await supabase
          .from('affiliate_commissions')
          .update({
            status: 'paid',
            payout_id: payoutId,
            paid_date: paymentDate || new Date(),
            status_changed_at: new Date(),
          })
          .eq('id', commission.id)
      }

      return NextResponse.json({ success: true, payout: { id: payoutId } }, { status: 200 })
    } catch (error) {
      console.error('Payout error:', error)
      return NextResponse.json(
        { error: error instanceof Error ? error.message : 'Unknown error' },
        { status: 500 }
      )
    }
  }

  return NextResponse.json({ error: 'Not found' }, { status: 404 })
}

/**
 * POST /api/admin/payouts/create-payout
 * Create a new payout from payable commissions
 * Body: { affiliateId, commissionIds }
 */
export async function POST(req: NextRequest) {
  if (req.nextUrl.pathname.includes('/admin/payouts')) {
    try {
      const { affiliateId, commissionIds } = await req.json()

      if (!affiliateId || !commissionIds || commissionIds.length === 0) {
        return NextResponse.json(
          { error: 'Missing affiliateId or commissionIds' },
          { status: 400 }
        )
      }

      // Get commissions and calculate total
      const { data: commissions } = await supabase
        .from('affiliate_commissions')
        .select('commission_amount_cents')
        .in('id', commissionIds)
        .eq('status', 'payable')

      const totalAmount = (commissions || []).reduce(
        (sum, c) => sum + c.commission_amount_cents,
        0
      )

      if (totalAmount === 0) {
        return NextResponse.json({ error: 'No payable commissions found' }, { status: 400 })
      }

      // Create payout record
      const { data: payout } = await supabase
        .from('affiliate_payouts')
        .insert({
          affiliate_id: affiliateId,
          amount_cents: totalAmount,
          status: 'pending',
        })
        .select()
        .single()

      // Update commissions with payout_id (but leave status as payable until marked paid)
      for (const commissionId of commissionIds) {
        await supabase
          .from('affiliate_commissions')
          .update({ payout_id: payout.id })
          .eq('id', commissionId)
      }

      return NextResponse.json(
        {
          success: true,
          payout: {
            id: payout.id,
            amount: (totalAmount / 100).toFixed(2),
            commissionCount: commissionIds.length,
          },
        },
        { status: 201 }
      )
    } catch (error) {
      console.error('Create payout error:', error)
      return NextResponse.json(
        { error: error instanceof Error ? error.message : 'Unknown error' },
        { status: 500 }
      )
    }
  }

  return NextResponse.json({ error: 'Not found' }, { status: 404 })
}
