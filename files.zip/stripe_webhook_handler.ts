// API route: /api/webhooks/stripe
import { createClient } from '@supabase/supabase-js'
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '', { apiVersion: '2024-06-20' })
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET!

/**
 * Main webhook handler for all Stripe events
 * Handles: charge.succeeded, charge.refunded, invoice.payment_succeeded, customer.subscription.deleted
 */
export async function handleStripeWebhook(event: Stripe.Event) {
  const { type, data } = event

  // Log the event
  await supabase.from('stripe_events_log').insert({
    stripe_event_id: event.id,
    event_type: type,
    payload: data,
    event_created_at: new Date(event.created * 1000),
  })

  try {
    switch (type) {
      // ========== PAYMENT SUCCESS ==========
      case 'charge.succeeded':
        await handleChargeSucceeded(data.object as Stripe.Charge)
        break

      // ========== PAYMENT FAILED ==========
      case 'charge.failed':
        await handleChargeFailed(data.object as Stripe.Charge)
        break

      // ========== REFUND ==========
      case 'charge.refunded':
        await handleChargeRefunded(data.object as Stripe.Charge)
        break

      // ========== SUBSCRIPTION CREATED (for recurring tracking) ==========
      case 'customer.subscription.created':
        await handleSubscriptionCreated(data.object as Stripe.Subscription)
        break

      // ========== SUBSCRIPTION DELETED ==========
      case 'customer.subscription.deleted':
        await handleSubscriptionDeleted(data.object as Stripe.Subscription)
        break

      // ========== INVOICE PAYMENT SUCCEEDED (recurring payments) ==========
      case 'invoice.payment_succeeded':
        await handleInvoicePaymentSucceeded(data.object as Stripe.Invoice)
        break

      default:
        console.log(`Unhandled event type ${type}`)
    }

    // Mark as processed
    await supabase
      .from('stripe_events_log')
      .update({ processed: true, processed_at: new Date() })
      .eq('stripe_event_id', event.id)
  } catch (error) {
    console.error(`Error processing webhook ${type}:`, error)
    await supabase
      .from('stripe_events_log')
      .update({
        processed: false,
        error_message: error instanceof Error ? error.message : String(error),
      })
      .eq('stripe_event_id', event.id)
    throw error
  }
}

/**
 * Handle successful payment
 * 1. Track in affiliate_sales
 * 2. Create commission(s)
 * 3. Update referral stats
 */
async function handleChargeSucceeded(charge: Stripe.Charge) {
  const { customer, amount, currency, metadata } = charge

  // Get referral code from metadata or payment intent
  const referralCode = metadata?.referral_code
  if (!referralCode) return // No affiliate involved

  // Find affiliate
  const { data: affiliate } = await supabase
    .from('affiliates')
    .select('id')
    .eq('referral_code', referralCode)
    .single()

  if (!affiliate) return

  // Determine product type
  const productType = metadata?.product_type || 'monthly'

  // Create sale record
  const { data: sale } = await supabase
    .from('affiliate_sales')
    .insert({
      affiliate_id: affiliate.id,
      customer_id: String(customer),
      customer_email: metadata?.customer_email,
      customer_name: metadata?.customer_name,
      product_type: productType,
      stripe_product_id: metadata?.stripe_product_id,
      stripe_price_id: metadata?.stripe_price_id,
      amount_cents: amount,
      currency: currency.toUpperCase(),
      stripe_payment_intent_id: charge.payment_intent as string,
      payment_status: 'succeeded',
    })
    .select('id')
    .single()

  if (!sale) return

  // Get commission rate from settings
  const { data: settings } = await supabase
    .from('affiliate_settings')
    .select('monthly_first_payment_commission, lifetime_commission')
    .single()

  const commissionRate =
    productType === 'lifetime'
      ? settings?.lifetime_commission || 20
      : settings?.monthly_first_payment_commission || 10

  const commissionAmount = Math.round((amount * commissionRate) / 100)

  // Create commission (pending for 30 days)
  await supabase.from('affiliate_commissions').insert({
    affiliate_id: affiliate.id,
    sale_id: sale.id,
    commission_type: productType === 'lifetime' ? 'lifetime_payment' : 'first_payment',
    commission_rate: commissionRate,
    sale_amount_cents: amount,
    commission_amount_cents: commissionAmount,
    status: 'pending',
    pending_until: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
  })

  // Update referral if exists
  if (metadata?.referral_id) {
    await supabase
      .from('referrals')
      .update({ converted: true, conversion_date: new Date(), customer_id: String(customer) })
      .eq('id', metadata.referral_id)
  }

  // Send email notification
  await sendAffiliateEmail(affiliate.id, 'sale_made', {
    customer_name: metadata?.customer_name,
    product_type: productType,
    amount: (amount / 100).toFixed(2),
    commission: (commissionAmount / 100).toFixed(2),
  })
}

/**
 * Handle charge failed - don't create commission
 */
async function handleChargeFailed(charge: Stripe.Charge) {
  const { metadata } = charge

  if (metadata?.referral_id) {
    await supabase
      .from('affiliate_sales')
      .insert({
        affiliate_id: metadata.affiliate_id,
        customer_email: metadata.customer_email,
        customer_id: String(charge.customer),
        product_type: metadata.product_type || 'monthly',
        amount_cents: charge.amount,
        payment_status: 'failed',
      })
      .throwOnError()
  }
}

/**
 * Handle refund - reverse commission
 */
async function handleChargeRefunded(charge: Stripe.Charge) {
  // Find the original sale
  const { data: sale } = await supabase
    .from('affiliate_sales')
    .select('id, affiliate_id')
    .eq('stripe_payment_intent_id', charge.payment_intent as string)
    .single()

  if (!sale) return

  // Update sale status
  await supabase
    .from('affiliate_sales')
    .update({
      payment_status: 'refunded',
      refund_amount_cents: charge.amount_refunded || 0,
      refund_date: new Date(),
    })
    .eq('id', sale.id)

  // Find and reverse commissions
  const { data: commissions } = await supabase
    .from('affiliate_commissions')
    .select('id')
    .eq('sale_id', sale.id)
    .in('status', ['pending', 'payable'])

  for (const commission of commissions || []) {
    await supabase
      .from('affiliate_commissions')
      .update({
        status: 'reversed',
        reversed_at: new Date(),
        reversal_reason: 'refund',
      })
      .eq('id', commission.id)
  }

  // Send refund notification
  const { data: affiliate } = await supabase
    .from('affiliates')
    .select('email')
    .eq('id', sale.affiliate_id)
    .single()

  if (affiliate) {
    await sendAffiliateEmail(sale.affiliate_id, 'refund_notice', {
      amount: (charge.amount_refunded || 0 / 100).toFixed(2),
    })
  }
}

/**
 * Handle subscription creation
 */
async function handleSubscriptionCreated(subscription: Stripe.Subscription) {
  // This is handled on first successful invoice payment
  console.log('Subscription created:', subscription.id)
}

/**
 * Handle subscription deletion - stop future recurring commissions
 */
async function handleSubscriptionDeleted(subscription: Stripe.Subscription) {
  // Find any sales with this subscription
  const { data: sales } = await supabase
    .from('affiliate_sales')
    .select('id, affiliate_id')
    .eq('stripe_subscription_id', subscription.id)

  if (!sales) return

  for (const sale of sales) {
    // Mark future commissions as cancelled
    await supabase
      .from('affiliate_commissions')
      .update({ status: 'rejected', reversal_reason: 'subscription_cancelled' })
      .eq('sale_id', sale.id)
      .eq('status', 'pending')
  }
}

/**
 * Handle recurring invoice payment
 * Creates new commission for each recurring payment
 */
async function handleInvoicePaymentSucceeded(invoice: Stripe.Invoice) {
  const { customer, amount_paid, currency, metadata } = invoice

  const referralCode = metadata?.referral_code
  if (!referralCode) return

  const { data: affiliate } = await supabase
    .from('affiliates')
    .select('id')
    .eq('referral_code', referralCode)
    .single()

  if (!affiliate) return

  // Find original sale to link
  const { data: originalSale } = await supabase
    .from('affiliate_sales')
    .select('id')
    .eq('stripe_subscription_id', invoice.subscription as string)
    .single()

  if (!originalSale) return

  // Get commission rate
  const { data: settings } = await supabase
    .from('affiliate_settings')
    .select('monthly_recurring_commission')
    .single()

  const commissionRate = settings?.monthly_recurring_commission || 10
  const commissionAmount = Math.round(((amount_paid || 0) * commissionRate) / 100)

  // Create new recurring commission
  await supabase.from('affiliate_commissions').insert({
    affiliate_id: affiliate.id,
    sale_id: originalSale.id,
    commission_type: 'recurring_payment',
    commission_rate: commissionRate,
    sale_amount_cents: amount_paid || 0,
    commission_amount_cents: commissionAmount,
    status: 'pending',
    pending_until: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
  })

  // Send recurring commission email
  await sendAffiliateEmail(affiliate.id, 'recurring_commission', {
    amount: ((amount_paid || 0) / 100).toFixed(2),
    commission: (commissionAmount / 100).toFixed(2),
  })
}

/**
 * Send email to affiliate
 */
async function sendAffiliateEmail(
  affiliateId: string,
  emailType: string,
  variables: Record<string, string>
) {
  const { data: affiliate } = await supabase
    .from('affiliates')
    .select('email')
    .eq('id', affiliateId)
    .single()

  if (!affiliate) return

  // Log email (implementation will depend on your email service)
  await supabase.from('affiliate_email_logs').insert({
    affiliate_id: affiliateId,
    recipient_email: affiliate.email,
    email_type: emailType,
    status: 'sent',
  })

  // TODO: Send actual email via your email service
  // For now, just log it
  console.log(`Email ${emailType} would be sent to ${affiliate.email}`)
}

/**
 * Verify webhook signature
 */
export function verifyWebhookSignature(
  body: string,
  signature: string,
  secret: string
): Stripe.Event {
  try {
    return stripe.webhooks.constructEvent(body, signature, secret)
  } catch (err) {
    throw new Error(`Webhook signature verification failed: ${err}`)
  }
}
