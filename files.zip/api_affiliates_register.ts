// File: app/api/affiliates/register/route.ts
import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

/**
 * POST /api/affiliates/register
 * Register a new affiliate
 * Body: { fullName, email, companyName, website, socialMediaHandle }
 */
export async function POST(req: NextRequest) {
  try {
    const { fullName, email, companyName, website, socialMediaHandle } = await req.json()

    // Validate required fields
    if (!fullName || !email) {
      return NextResponse.json(
        { error: 'Missing required fields: fullName, email' },
        { status: 400 }
      )
    }

    // Get user ID from auth header
    const authHeader = req.headers.get('authorization')
    if (!authHeader) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Generate unique referral code (format: JOSH-ABC123)
    const referralCode = generateReferralCode(fullName)

    // Check if email already registered
    const { data: existing } = await supabase
      .from('affiliates')
      .select('id')
      .eq('email', email)

    if (existing && existing.length > 0) {
      return NextResponse.json({ error: 'Email already registered as affiliate' }, { status: 409 })
    }

    // Check if referral code exists
    const { data: existingCode } = await supabase
      .from('affiliates')
      .select('id')
      .eq('referral_code', referralCode)

    let finalCode = referralCode
    if (existingCode && existingCode.length > 0) {
      finalCode = `${referralCode}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
    }

    // Get auth user ID (this would come from your auth system)
    // For now, we'll generate a UUID - you should replace this with actual user_id
    const userId = crypto.randomUUID()

    // Create affiliate
    const { data: affiliate, error } = await supabase
      .from('affiliates')
      .insert({
        user_id: userId,
        referral_code: finalCode,
        full_name: fullName,
        email,
        company_name: companyName || null,
        website: website || null,
        social_media_handle: socialMediaHandle || null,
        status: 'pending', // Admin must approve
      })
      .select()
      .single()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json(
      {
        success: true,
        affiliate: {
          id: affiliate.id,
          referralCode: affiliate.referral_code,
          status: affiliate.status,
          message: 'Registration successful! Awaiting admin approval.',
        },
      },
      { status: 201 }
    )
  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

/**
 * Generate referral code from name
 * Example: "Josh Thach" -> "JOSH-ABC123"
 */
function generateReferralCode(name: string): string {
  const firstWord = name.split(' ')[0].toUpperCase().slice(0, 6)
  const randomSuffix = Math.random().toString(36).substr(2, 6).toUpperCase()
  return `${firstWord}-${randomSuffix}`
}
