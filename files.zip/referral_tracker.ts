// File: lib/referral-tracker.ts
/**
 * Referral tracking utility
 * Handles capturing referral codes from URL params and storing them
 */

const REFERRAL_CODE_KEY = 'preemiyum_referral_code'
const REFERRAL_ID_KEY = 'preemiyum_referral_id'
const VISITOR_ID_KEY = 'preemiyum_visitor_id'

/**
 * Initialize referral tracking
 * Call this on page load or route change
 */
export async function initializeReferralTracking() {
  // Get referral code from URL
  const params = new URLSearchParams(window.location.search)
  const referralCode = params.get('ref')

  if (!referralCode) return

  // Store in localStorage
  localStorage.setItem(REFERRAL_CODE_KEY, referralCode)

  // Generate visitor ID if not exists
  let visitorId = localStorage.getItem(VISITOR_ID_KEY)
  if (!visitorId) {
    visitorId = generateVisitorId()
    localStorage.setItem(VISITOR_ID_KEY, visitorId)
  }

  // Track the click
  try {
    await fetch('/api/referrals/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        referralCode,
        visitorId,
        visitorIp: await getVisitorIp(),
        userAgent: navigator.userAgent,
        country: await getVisitorCountry(),
      }),
    })
  } catch (error) {
    console.error('Failed to track referral click:', error)
  }
}

/**
 * Get stored referral code (for use during checkout/signup)
 */
export function getReferralCode(): string | null {
  return localStorage.getItem(REFERRAL_CODE_KEY)
}

/**
 * Get stored visitor ID
 */
export function getVisitorId(): string | null {
  return localStorage.getItem(VISITOR_ID_KEY)
}

/**
 * Clear referral code (after successful signup)
 */
export function clearReferralCode() {
  localStorage.removeItem(REFERRAL_CODE_KEY)
}

/**
 * Generate unique visitor ID
 */
function generateVisitorId(): string {
  return `visitor_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

/**
 * Get visitor IP (calls backend to get IP from request)
 * For client-side tracking, this is approximate
 */
async function getVisitorIp(): Promise<string> {
  try {
    const response = await fetch('https://api.ipify.org?format=json')
    const data = await response.json()
    return data.ip || 'unknown'
  } catch {
    return 'unknown'
  }
}

/**
 * Get visitor country (approximate based on browser language)
 */
async function getVisitorCountry(): Promise<string> {
  // Use timezone-based country detection as fallback
  try {
    const formatter = new Intl.DateTimeFormat(undefined, { timeZone: 'UTC' })
    const tz = formatter.resolvedOptions().timeZone
    // Map timezone to country (simplified)
    return tz.split('/')[0] || 'unknown'
  } catch {
    return 'unknown'
  }
}

/**
 * Create referral URL
 * Usage: generateReferralUrl('JOSH-ABC123') -> '/checkout?ref=JOSH-ABC123'
 */
export function generateReferralUrl(referralCode: string): string {
  return `${window.location.origin}?ref=${encodeURIComponent(referralCode)}`
}

/**
 * Track conversion (when user signs up via referral)
 */
export async function trackConversion(customerId: string, customerEmail: string) {
  const referralCode = getReferralCode()
  if (!referralCode) return

  try {
    await fetch('/api/referrals/conversion', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        referralCode,
        customerId,
        customerEmail,
        visitorId: getVisitorId(),
      }),
    })
  } catch (error) {
    console.error('Failed to track conversion:', error)
  }
}
