// File: app/api/affiliates/dashboard/route.ts
import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

/**
 * GET /api/affiliates/dashboard
 * Get affiliate dashboard data
 * Query params: affiliateId (or get from auth)
 */
export async function GET(req: NextRequest) {
  try {
    const affiliateId = req.nextUrl.searchParams.get('affiliateId')

    if (!affiliateId) {
      return NextResponse.json({ error: 'Missing affiliateId' }, { status: 400 })
    }

    // Fetch affiliate data
    const { data: affiliate } = await supabase
      .from('affiliates')
      .select('*')
      .eq('id', affiliateId)
      .single()

    if (!affiliate) {
      return NextResponse.json({ error: 'Affiliate not found' }, { status: 404 })
    }

    // Fetch commission stats
    const { data: commissions } = await supabase
      .from('affiliate_commissions')
      .select('status, commission_amount_cents')
      .eq('affiliate_id', affiliateId)

    const commissionStats = {
      pending: 0,
      payable: 0,
      paid: 0,
    }

    let totalEarnings = 0

    for (const commission of commissions || []) {
      const amount = commission.commission_amount_cents / 100
      if (commission.status === 'pending') commissionStats.pending += amount
      else if (commission.status === 'payable') commissionStats.payable += amount
      else if (commission.status === 'paid') {
        commissionStats.paid += amount
        totalEarnings += amount
      }
    }

    // Fetch recent sales
    const { data: recentSales } = await supabase
      .from('affiliate_sales')
      .select(
        `
        id,
        customer_name,
        product_type,
        amount_cents,
        payment_status,
        sale_date
      `
      )
      .eq('affiliate_id', affiliateId)
      .order('sale_date', { ascending: false })
      .limit(10)

    // Fetch referral stats
    const { data: referrals } = await supabase
      .from('referrals')
      .select('click_count, converted')
      .eq('affiliate_id', affiliateId)

    let totalClicks = 0
    let totalConversions = 0

    for (const referral of referrals || []) {
      totalClicks += referral.click_count || 0
      if (referral.converted) totalConversions++
    }

    // Fetch referral link stats
    const { data: sales } = await supabase
      .from('affiliate_sales')
      .select('product_type, amount_cents')
      .eq('affiliate_id', affiliateId)

    let monthlyRevenue = 0
    let lifetimeRevenue = 0

    for (const sale of sales || []) {
      if (sale.product_type === 'monthly') {
        monthlyRevenue += sale.amount_cents / 100
      } else if (sale.product_type === 'lifetime') {
        lifetimeRevenue += sale.amount_cents / 100
      }
    }

    // Calculate conversion rate
    const totalReferrals = referrals?.length || 0
    const conversionRate =
      totalReferrals > 0 ? ((totalConversions / totalReferrals) * 100).toFixed(2) : '0.00'

    // Get leaderboard position (simplified)
    const { data: topAffiliates } = await supabase
      .from('affiliates')
      .select('id, lifetime_earnings')
      .order('lifetime_earnings', { ascending: false })
      .limit(100)

    const leaderboardPosition =
      topAffiliates?.findIndex((a) => a.id === affiliateId) + 1 || 0

    return NextResponse.json(
      {
        affiliate: {
          id: affiliate.id,
          fullName: affiliate.full_name,
          referralCode: affiliate.referral_code,
          status: affiliate.status,
          lifetimeEarnings: affiliate.lifetime_earnings,
        },
        stats: {
          totalClicks,
          totalConversions,
          conversionRate: `${conversionRate}%`,
          monthlyRevenue: monthlyRevenue.toFixed(2),
          lifetimeRevenue: lifetimeRevenue.toFixed(2),
        },
        commissions: {
          pending: commissionStats.pending.toFixed(2),
          payable: commissionStats.payable.toFixed(2),
          paid: commissionStats.paid.toFixed(2),
        },
        recentSales: (recentSales || []).map((sale) => ({
          id: sale.id,
          customerName: sale.customer_name,
          productType: sale.product_type,
          amount: (sale.amount_cents / 100).toFixed(2),
          status: sale.payment_status,
          date: new Date(sale.sale_date).toLocaleDateString(),
        })),
        leaderboard: {
          position: leaderboardPosition,
          totalAffiliates: topAffiliates?.length || 0,
        },
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Dashboard error:', error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
