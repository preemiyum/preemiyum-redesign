// File: app/api/admin/dashboard/route.ts
import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

/**
 * GET /api/admin/dashboard
 * Admin analytics dashboard
 */
export async function GET(req: NextRequest) {
  try {
    // Check admin access (implement based on your auth system)
    // For now, assuming valid request

    // Get date ranges
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000)
    const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000)

    // ========== REVENUE METRICS ==========
    const { data: todayRevenue } = await supabase
      .from('affiliate_sales')
      .select('amount_cents')
      .eq('payment_status', 'succeeded')
      .gte('sale_date', today.toISOString())

    const { data: weekRevenue } = await supabase
      .from('affiliate_sales')
      .select('amount_cents')
      .eq('payment_status', 'succeeded')
      .gte('sale_date', weekAgo.toISOString())

    const { data: monthRevenue } = await supabase
      .from('affiliate_sales')
      .select('amount_cents')
      .eq('payment_status', 'succeeded')
      .gte('sale_date', monthAgo.toISOString())

    // Breakdown by product type
    const { data: allSales } = await supabase
      .from('affiliate_sales')
      .select('amount_cents, product_type, payment_status')
      .eq('payment_status', 'succeeded')

    let monthlyMembershipRevenue = 0
    let lifetimeMembershipRevenue = 0
    let totalAffiliateRevenue = 0

    for (const sale of allSales || []) {
      if (sale.product_type === 'monthly') {
        monthlyMembershipRevenue += sale.amount_cents / 100
      } else if (sale.product_type === 'lifetime') {
        lifetimeMembershipRevenue += sale.amount_cents / 100
      }
    }

    // Get total affiliate revenue from commissions
    const { data: paidCommissions } = await supabase
      .from('affiliate_commissions')
      .select('commission_amount_cents')
      .eq('status', 'paid')

    for (const commission of paidCommissions || []) {
      totalAffiliateRevenue += commission.commission_amount_cents / 100
    }

    // ========== COMMISSION METRICS ==========
    const { data: allCommissions } = await supabase
      .from('affiliate_commissions')
      .select('status, commission_amount_cents')

    let pendingCommissions = 0
    let payableCommissions = 0
    let paidCommissionsTotal = 0
    let outstandingCommissions = 0

    for (const commission of allCommissions || []) {
      if (commission.status === 'pending') {
        pendingCommissions += commission.commission_amount_cents / 100
      } else if (commission.status === 'payable') {
        payableCommissions += commission.commission_amount_cents / 100
        outstandingCommissions += commission.commission_amount_cents / 100
      } else if (commission.status === 'paid') {
        paidCommissionsTotal += commission.commission_amount_cents / 100
      }
    }

    // ========== TOP AFFILIATES ==========
    const { data: topAffiliates } = await supabase
      .from('affiliates')
      .select('id, full_name, lifetime_earnings, total_conversions, total_clicks')
      .order('lifetime_earnings', { ascending: false })
      .limit(10)

    // ========== RECENT SALES ==========
    const { data: recentSales } = await supabase
      .from('affiliate_sales')
      .select(
        `
        id,
        customer_name,
        customer_email,
        product_type,
        amount_cents,
        payment_status,
        sale_date,
        affiliates(full_name, referral_code)
      `
      )
      .order('sale_date', { ascending: false })
      .limit(20)

    // ========== PENDING PAYOUTS ==========
    const { data: pendingPayouts } = await supabase
      .from('affiliate_payouts')
      .select(
        `
        id,
        amount_cents,
        created_at,
        affiliates(full_name, email)
      `
      )
      .eq('status', 'pending')

    // ========== PAYOUT QUEUE (unpaid commissions) ==========
    const { data: payoutQueue } = await supabase
      .from('affiliate_commissions')
      .select(
        `
        id,
        commission_amount_cents,
        affiliates(full_name, email)
      `
      )
      .eq('status', 'payable')
      .order('created_at', { ascending: true })

    const formattedPayoutQueue = (payoutQueue || []).map((item) => ({
      affiliateName: item.affiliates?.full_name,
      affiliateEmail: item.affiliates?.email,
      amount: (item.commission_amount_cents / 100).toFixed(2),
    }))

    return NextResponse.json(
      {
        revenue: {
          today: (todayRevenue?.reduce((sum, sale) => sum + sale.amount_cents, 0) / 100).toFixed(
            2
          ),
          week: (weekRevenue?.reduce((sum, sale) => sum + sale.amount_cents, 0) / 100).toFixed(
            2
          ),
          month: (monthRevenue?.reduce((sum, sale) => sum + sale.amount_cents, 0) / 100).toFixed(
            2
          ),
          monthlyMembership: monthlyMembershipRevenue.toFixed(2),
          lifetimeMembership: lifetimeMembershipRevenue.toFixed(2),
        },
        commissions: {
          pending: pendingCommissions.toFixed(2),
          payable: payableCommissions.toFixed(2),
          paid: paidCommissionsTotal.toFixed(2),
          outstanding: outstandingCommissions.toFixed(2),
        },
        topAffiliates: (topAffiliates || []).map((affiliate) => ({
          id: affiliate.id,
          name: affiliate.full_name,
          earnings: affiliate.lifetime_earnings,
          conversions: affiliate.total_conversions,
          clicks: affiliate.total_clicks,
        })),
        recentSales: (recentSales || []).map((sale) => ({
          id: sale.id,
          affiliateName: sale.affiliates?.full_name,
          customerName: sale.customer_name,
          customerEmail: sale.customer_email,
          productType: sale.product_type,
          amount: (sale.amount_cents / 100).toFixed(2),
          status: sale.payment_status,
          date: new Date(sale.sale_date).toISOString(),
        })),
        pendingPayouts: (pendingPayouts || []).map((payout) => ({
          id: payout.id,
          affiliateName: payout.affiliates?.full_name,
          affiliateEmail: payout.affiliates?.email,
          amount: (payout.amount_cents / 100).toFixed(2),
          date: new Date(payout.created_at).toISOString(),
        })),
        payoutQueue: formattedPayoutQueue,
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('Admin dashboard error:', error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}
